import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopebarComponent } from './topebar.component';

describe('TopebarComponent', () => {
  let component: TopebarComponent;
  let fixture: ComponentFixture<TopebarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TopebarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TopebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
