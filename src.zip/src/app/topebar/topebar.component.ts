import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topebar',
  templateUrl: './topebar.component.html',
  styleUrls: ['./topebar.component.css']
})
export class TopebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
