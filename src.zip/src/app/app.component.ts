import { Component } from '@angular/core';
import {Object} from "./model";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angularDemo3';
  data:Array<Object>=[
    {
        planName:"EARNINGS (MONTHLY)",
        Value:"$40,000"

    },
    {
      planName:"EARNINGS (ANNUAL) ",
      Value:"$215,000"

    },
    {
      planName:"TASKS",
      Value:"50%"
    },
    {
      planName:"PENDING REQUESTS",
      Value:"18"
    }
  ]

  constructor(){
    this.data.forEach((element) => {

    })
  }
}
