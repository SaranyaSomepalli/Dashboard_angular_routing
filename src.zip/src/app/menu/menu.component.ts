import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import {Object} from '../model'
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})

export class MenuComponent implements OnInit {
  @Input('priceObj') priceObj:Partial<Object>={}

  constructor() { }

  ngOnInit(): void {
  }

}
