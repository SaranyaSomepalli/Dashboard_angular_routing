import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AnimationComponent } from './animation/animation.component';
import { BordersComponent } from './borders/borders.component';
import { ButtonsComponent } from './buttons/buttons.component';
import { CardsComponent } from './cards/cards.component';
import { ColorsComponent } from './colors/colors.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { RegisterComponent } from './register/register.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { TopebarComponent } from './topebar/topebar.component';

const routes: Routes = [
  {
    path:'',
    component : MenuComponent
  },
  {
    path:'',
    component : SidebarComponent
  },
  {
    path:'',
    component : TopebarComponent
  },
  {
    path :'login',
    component :  LoginComponent
  },
  {
    path : 'register',
    component : RegisterComponent
  },
  {
    path:'ForgotPassword',
    component : ForgotpasswordComponent
  },
  {
    path:'buttons',
    component : ButtonsComponent
  },
  {
    path:'cards',
    component : CardsComponent
  },
  {
    path:'colors',
    component : ColorsComponent
  },
  {
    path:'borders',
    component : BordersComponent
  },
  {
    path:'animation',
    component : AnimationComponent
  }
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
